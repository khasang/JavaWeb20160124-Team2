CREATE TABLE `webstore`.`allTableDB` (
  `Id` INT NOT NULL,
  `tName` LONGTEXT NOT NULL,
  `description` MEDIUMTEXT NULL,
  PRIMARY KEY (`Id`));