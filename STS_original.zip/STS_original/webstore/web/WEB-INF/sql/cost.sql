CREATE TABLE `webstore`.`costs` (
  `id` INT NOT NULL,
  `cost` INT NULL,
  PRIMARY KEY (`id`));

INSERT INTO `webstore`.`cost1` (`ID`, `cost`) VALUES ('1', '100');
INSERT INTO `webstore`.`cost1` (`ID`, `cost`) VALUES ('2', '89');
INSERT INTO `webstore`.`cost1` (`ID`, `cost`) VALUES ('3', '30');
INSERT INTO `webstore`.`cost1` (`ID`, `cost`) VALUES ('4', '56');
INSERT INTO `webstore`.`cost1` (`ID`, `cost`) VALUES ('5', '200');
INSERT INTO `webstore`.`cost1` (`ID`, `cost`) VALUES ('6', '25');
INSERT INTO `webstore`.`cost1` (`ID`, `cost`) VALUES ('7', '50');
INSERT INTO `webstore`.`cost1` (`ID`, `cost`) VALUES ('8', '28');