INSERT INTO `webstore`.`logins` (`id`, `login`, `password`, `security`) VALUES ('1', 'user1', '123', 'qqq');
INSERT INTO `webstore`.`logins` (`id`, `login`, `password`, `security`) VALUES ('2', 'user2', '456', 'www');
INSERT INTO `webstore`.`logins` (`id`, `login`, `password`, `security`) VALUES ('3', 'Uasya', '111', 'aaa');
INSERT INTO `webstore`.`logins` (`id`, `login`, `password`, `security`) VALUES ('4', 'Masha', '222', 'sss');
