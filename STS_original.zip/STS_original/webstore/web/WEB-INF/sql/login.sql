CREATE TABLE `webstore`.`logins` (
  `id` INT NOT NULL,
  `login` VARCHAR(45) NOT NULL,
  `password` VARCHAR(45) NOT NULL,
  `security` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`));
