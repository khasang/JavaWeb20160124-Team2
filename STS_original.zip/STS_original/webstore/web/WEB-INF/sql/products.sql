CREATE TABLE `webstore`.`products` (
  `id` INT NOT NULL,
  `pname` MEDIUMTEXT NOT NULL,
  `productorder` LONGTEXT NOT NULL,
  PRIMARY KEY (`id`));